SKIPUNZIP=1
ui_print "- Storage Isolation NS Fix v0.5.0 (A16/HyperOS3 adaptive)"
unzip -o "$ZIPFILE" "module.prop" "service.sh" "uninstall.sh" "sepolicy.rule" -d "$MODPATH" >/dev/null 2>&1
[ -f "$MODPATH/service.sh" ] || abort "! Extraction failed"
set_perm "$MODPATH/module.prop"   0 0 0644
set_perm "$MODPATH/service.sh"    0 0 0700
set_perm "$MODPATH/uninstall.sh"  0 0 0700
set_perm "$MODPATH/sepolicy.rule" 0 0 0644
if [ ! -f /data/adb/si_nsfix_targets.txt ]; then
  unzip -o "$ZIPFILE" "si_nsfix_targets.txt" -d "$MODPATH" >/dev/null 2>&1
  cp "$MODPATH/si_nsfix_targets.txt" /data/adb/si_nsfix_targets.txt 2>/dev/null
  ui_print "- Default repair list installed (80 pkgs, edit anytime)"
else
  ui_print "- Keep existing /data/adb/si_nsfix_targets.txt"
fi
ui_print "- Auto: zygote/daemon/users detect + running app repair"
ui_print "- Installed. Reboot to activate."
