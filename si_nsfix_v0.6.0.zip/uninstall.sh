#!/system/bin/sh
# si_nsfix v0.6.0 uninstall —— 杀 watchdog + 还原 zygote 的 /mnt/user 侧绑定
# 注: 绑进运行中 app 的视图随该 app 进程重启自然消失
for p in $(pgrep -f "/si_nsfix/service.sh" 2>/dev/null); do
  kill "$p" 2>/dev/null
done
NSENTER=""
nsenter --help >/dev/null 2>&1 && NSENTER="nsenter"
if [ -z "$NSENTER" ]; then
  for b in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
    [ -x "$b" ] && "$b" nsenter --help >/dev/null 2>&1 && NSENTER="$b nsenter" && break
  done
fi
[ -z "$NSENTER" ] && rm -f /data/adb/si_nsfix.log && exit 0
for Z in $(pidof zygote64) $(pidof zygote) $(pidof zygote32); do
  for USR in $(ls /mnt/user 2>/dev/null); do
    case "$USR" in (*[!0-9]*|'') continue;; esac
    $NSENTER -t "$Z" -m -- umount \
      "/mnt/user/$USR/emulated/$USR/Android/obb" \
      "/mnt/user/$USR/emulated/$USR/Android/media" 2>/dev/null
  done
done
rm -f /data/adb/si_nsfix.log
