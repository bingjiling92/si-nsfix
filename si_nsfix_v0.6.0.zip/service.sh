#!/system/bin/sh
# si_nsfix v0.6.0 —— A16/HyperOS3 自适应版(数据修正)
# 依据 v0.5.0 实测日志的三个结论:
#   1. /storage/emulated/* 在 zygote/daemon ns 里结构性不存在 -> zygote 侧只补 /mnt/user
#   2. /mnt/user 侧 zygote 视图部分开机原生就有(竞态), 部分开机缺失 -> 保留幂等补齐
#   3. v0.5.0 的 apply_running 零动作(awk/pgrep/stat 在 toybox 上的兼容坑)
#      -> v0.6.0 全部改纯 sh 实现, 并加周期诊断计数
# 修复运行中 app 的方式(核心改进):
#   跨侧取源: 源=daemon 的 /mnt/user/<u>/emulated/<u>/Android/{obb,media}
#             目标=app ns 的 /storage/emulated/<u>/Android/... 与 /mnt/user/.../Android/...
#   mkdir 兜底: 目标目录在 FUSE 视图缺失时, 先在目标 ns 里 mkdir -p 再 bind

MODDIR=${0%/*}
LOG=/data/adb/si_nsfix.log
GUARD=/data/adb/modules/si_nsfix
FAIL_STATE=/data/adb/storage-isolation/guard_fail.state
TARGETS_FILE=/data/adb/si_nsfix_targets.txt
DIAG_FLAG=/data/adb/si_nsfix_diag
log(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

find_bb(){
  for b in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
    [ -x "$b" ] && { echo "$b"; return 0; }
  done
  return 1
}
NSENTER=""
nsenter --help >/dev/null 2>&1 && NSENTER="nsenter"
if [ -z "$NSENTER" ]; then
  BB=$(find_bb)
  [ -n "$BB" ] && "$BB" nsenter --help >/dev/null 2>&1 && NSENTER="$BB nsenter"
fi
[ -z "$NSENTER" ] && { log "FATAL: no nsenter available"; exit 1; }

daemon_pid(){
  D=$(pidof storage_isolation_daemon 2>/dev/null); D=${D%% *}
  [ -n "$D" ] && { echo "$D"; return 0; }
  D=$(pgrep -f "/data/adb/storage-isolation/bin/daemon-" 2>/dev/null | head -n 1)
  [ -n "$D" ] && { echo "$D"; return 0; }
  return 1
}

# 纯 sh: 从 /proc/$1/status 取 Uid 第2字段
uid_of(){
  set -- $(grep '^Uid:' "/proc/$1/status" 2>/dev/null)
  [ -n "$2" ] && { echo "$2"; return 0; }
  return 1
}

# 纯 sh: 进程首 token 是否等于 $2 或以 "$2:" 开头
cmdline_is(){ # $1=pid $2=pkg
  T=$(tr '\0' '\n' < "/proc/$1/cmdline" 2>/dev/null | head -n 1)
  [ "$T" = "$2" ] && return 0
  case "$T" in "$2:"*) return 0 ;; esac
  return 1
}

zygote_pids(){
  for p in /proc/[0-9]*; do
    P=${p#/proc/}
    cmdline_is "$P" "zygote64" || cmdline_is "$P" "zygote" || continue
    set -- $(grep '^PPid:' "/proc/$P/status" 2>/dev/null)
    [ "$2" = "1" ] || continue          # 排除 fork 后未 specialize 的瞬态子进程
    echo "$P"
  done
}

# 目标 ns 补一个视图: 跨侧源 + mkdir 兜底
seed(){ # $1=pid $2=目标ns内路径 $3=相对root的源路径
  ls "/proc/$1/root$2/" >/dev/null 2>&1 && return 0
  [ -d "/proc/$DAEMON/root$3" ] || { SKIP=$((SKIP+1)); return 0; }
  if ! $NSENTER -t "$1" -m -- mkdir -p "$2" 2>>"$LOG"; then
    log "FAILED mkdir $2 -> pid $1"; FAILC=$((FAILC+1)); return 1
  fi
  if $NSENTER -t "$1" -m -- mount --bind "/proc/$DAEMON/root$3" "$2" 2>>"$LOG"; then
    log "bound $2 -> pid $1"; BOUND=$((BOUND+1)); return 0
  fi
  log "FAILED bind $2 -> pid $1"; FAILC=$((FAILC+1)); return 1
}

apply_zygote(){
  DAEMON=$(daemon_pid) || return 0
  BOUND=0; FAILC=0; SKIP=0
  for Z in $(zygote_pids); do
    for USR in $(ls /mnt/user 2>/dev/null); do
      case "$USR" in (*[!0-9]*|'') continue;; esac
      M="/mnt/user/$USR/emulated/$USR/Android"
      for SUB in obb media; do
        seed "$Z" "$M/$SUB" "$M/$SUB"
      done
    done
  done
  [ $BOUND -gt 0 -o $FAILC -gt 0 ] && log "cycle zygote: bound=$BOUND failed=$FAILC skipped=$SKIP"
  return 0
}

collect_targets(){
  if [ -f "$FAIL_STATE" ]; then
    while read -r PKG CNT _; do
      case "$PKG" in ''|\#*) continue ;; esac
      case "$CNT" in ''|*[!0-9]*) continue ;; esac
      [ "$CNT" -gt 0 ] && echo "$PKG"
    done < "$FAIL_STATE"
  fi
  [ -f "$TARGETS_FILE" ] && grep -v '^#' "$TARGETS_FILE" 2>/dev/null
  return 0
}

apply_running(){
  DAEMON=$(daemon_pid) || return 0
  BOUND=0; FAILC=0; SKIP=0; NP=0
  LIST=$(collect_targets | sort -u)
  for PKG in $LIST; do
    [ -n "$PKG" ] || continue
    case "$PKG" in android|*providers.media*) continue ;; esac
    for p in /proc/[0-9]*; do
      P=${p#/proc/}
      cmdline_is "$P" "$PKG" || continue
      NP=$((NP+1))
      U=$(uid_of "$P") || continue
      [ "$U" -lt 10000 ] && continue
      USR=$((U / 100000))
      [ "$USR" -ne 0 ] && continue
      ls "/proc/$P/root/storage/emulated/0/" >/dev/null 2>&1 || continue
      MSRC="/mnt/user/0/emulated/0/Android"
      for TGT in "/storage/emulated/0/Android" "/mnt/user/0/emulated/0/Android"; do
        for SUB in obb media; do
          seed "$P" "$TGT/$SUB" "$MSRC/$SUB"
        done
      done
    done
  done
  if [ $BOUND -gt 0 ] || [ $FAILC -gt 0 ] || [ -f "$DIAG_FLAG" ]; then
    log "cycle apps: pids=$NP bound=$BOUND failed=$FAILC skipped=$SKIP targets=$(echo $LIST | wc -w)"
  fi
  return 0
}

log "=== si_nsfix v0.6.0 start (nsenter=$NSENTER) ==="
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 20
( while true; do
    [ -d "$GUARD" ] || { log "module gone, watchdog exit"; exit 0; }
    [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 524288 ] && : > "$LOG"
    apply_zygote
    apply_running
    sleep 30
  done ) &
log "watchdog started"
