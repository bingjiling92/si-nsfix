#!/system/bin/sh
# si_nsfix v0.5.0 uninstall —— 先杀 watchdog, 再还原所有 zygote 视图
# 注: 已 bind 进运行中 app 的视图随进程重启自然消失, 无需处理
for p in $(pgrep -f "/si_nsfix/service.sh" 2>/dev/null); do
  kill "$p" 2>/dev/null
done
NSENTER=""
nsenter --help >/dev/null 2>&1 && NSENTER="nsenter"
if [ -z "$NSENTER" ]; then
  for b in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
    [ -x "$b" ] && "$b" nsenter --help >/dev/null 2>&1 && NSENTER="$b nsenter" && break
  done
fi
ZS="$(pidof zygote64 2>/dev/null) $(pidof zygote 2>/dev/null) $(pidof zygote32 2>/dev/null)"
if [ -n "$NSENTER" ] && [ -n "$ZS" ]; then
  for Z in $ZS; do
    for USR in $(ls /mnt/user 2>/dev/null | grep -E '^[0-9]+$'); do
      $NSENTER -t "$Z" -m -- umount \
        "/storage/emulated/$USR/Android/obb" "/storage/emulated/$USR/Android/media" \
        "/mnt/user/$USR/emulated/$USR/Android/obb" "/mnt/user/$USR/emulated/$USR/Android/media" 2>/dev/null
    done
  done
fi
rm -f /data/adb/si_nsfix.log
