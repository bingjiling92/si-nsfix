#!/system/bin/sh
# si_nsfix v0.5.0 —— A16/HyperOS3 自适应版
# 数据驱动的设计来源:
#   zn_guard.log      : "repair FAILED (mounts still bad)" —— daemon 修运行中 pid 时目标视图缺失
#   guard_fail.state  : 故障包清单(com.tencent.mm=60 等) —— 动态修复名单
#   configuration.json: 80 个启用隔离的包 —— 默认名单
#   modules_info/logcat: zygote64 单实例、daemon 名 storage_isolation_daemon
# 核心动作: 把 daemon ns 的 Android/{obb,media} FUSE 视图 bind 进
#   (1) 所有 zygote ns        -> 之后新 spawn 的 app 全部继承
#   (2) 故障/名单 app 的运行中 ns -> 解锁 zn_guard 的修复死局
# 安全: 按 /proc/PID 的 uid 折算 user, 只把对应用户的视图 bind 给对应用户的进程;
#       MediaProvider(FUSE 本体)与系统进程永不触碰。

MODDIR=${0%/*}
LOG=/data/adb/si_nsfix.log
GUARD=/data/adb/modules/si_nsfix
FAIL_STATE=/data/adb/storage-isolation/guard_fail.state
TARGETS_FILE=/data/adb/si_nsfix_targets.txt
log(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

# ---------- 工具: busybox 回退(KSU/Magisk/APatch) ----------
find_bb(){
  for b in /data/adb/ksu/bin/busybox /data/adb/magisk/busybox /data/adb/ap/bin/busybox; do
    [ -x "$b" ] && { echo "$b"; return 0; }
  done
  return 1
}

NSENTER=""
nsenter --help >/dev/null 2>&1 && NSENTER="nsenter"
if [ -z "$NSENTER" ]; then
  BB=$(find_bb)
  [ -n "$BB" ] && "$BB" nsenter --help >/dev/null 2>&1 && NSENTER="$BB nsenter"
fi
if [ -z "$NSENTER" ]; then
  log "FATAL: no nsenter available (toybox/ksu/magisk/apatch busybox)"
  exit 1
fi

daemon_pid(){
  D=$(pidof storage_isolation_daemon 2>/dev/null); D=${D%% *}
  [ -n "$D" ] && { echo "$D"; return 0; }
  D=$(pgrep -f "/data/adb/storage-isolation/bin/daemon-" 2>/dev/null | head -n 1)
  [ -n "$D" ] && { echo "$D"; return 0; }
  return 1
}

zygote_pids(){
  pidof zygote64 2>/dev/null
  pidof zygote    2>/dev/null
  pidof zygote32  2>/dev/null
}

# 返回: 0=已就绪 1=本次绑定 2=失败 3=源侧缺失
bind_if_missing(){ # $1=from_pid $2=to_pid $3=path
  ls "/proc/$2/root$3/" >/dev/null 2>&1 && return 0
  ls "/proc/$1/root$3/" >/dev/null 2>&1 || return 3
  if $NSENTER -t "$2" -m -- mount --bind "/proc/$1/root$3" "$3" 2>>"$LOG"; then
    return 1
  fi
  return 2
}

# 对一个目标进程补齐其所属 user 的 4 个视图
fix_pid(){ # $1=pid
  P=$1
  U_ID=$(stat -c %u "/proc/$P" 2>/dev/null) || return 0
  [ -z "$U_ID" ] && return 0
  [ "$U_ID" -lt 10000 ] && return 0          # 系统/根进程不碰
  USR=$((U_ID / 100000))
  [ "$USR" -ne 0 ] && return 0               # SI 配置目前仅 user 0; 双开进程不污染
  ls "/proc/$P/root/storage/emulated/0/" >/dev/null 2>&1 || return 0   # 无存储视图(isolated)跳过
  for SUB in obb media; do
    for BASEP in "/storage/emulated/0" "/mnt/user/0/emulated/0"; do
      PTH="$BASEP/Android/$SUB"
      bind_if_missing "$1" "$P" "$PTH"; r=$?
      case $r in
        1) log "bound $PTH -> pid $P" ;;
        2) log "FAILED $PTH -> pid $P" ;;
      esac
    done
  done
}

apply_zygote(){
  D=$(daemon_pid) || return 0
  for Z in $(zygote_pids); do
    [ -n "$Z" ] || continue
    for USR in $(ls /mnt/user 2>/dev/null | grep -E '^[0-9]+$'); do
      for BASEP in "/storage/emulated/$USR" "/mnt/user/$USR/emulated/$USR"; do
        for SUB in obb media; do
          PTH="$BASEP/Android/$SUB"
          bind_if_missing "$D" "$Z" "$PTH"; r=$?
          case $r in
            1) log "bound $PTH -> zygote($Z)" ;;
            3) log "skip  $PTH (missing in daemon($D) ns)" ;;
            2) log "FAILED $PTH -> zygote($Z)" ;;
          esac
        done
      done
    done
  done
}

collect_targets(){
  [ -f "$FAIL_STATE" ] && awk '$2>0{print $1}' "$FAIL_STATE" 2>/dev/null
  [ -f "$TARGETS_FILE" ] && grep -v '^#' "$TARGETS_FILE" 2>/dev/null
}

apply_running(){
  daemon_pid || return 0
  collect_targets | sort -u | while read -r PKG; do
    [ -n "$PKG" ] || continue
    case "$PKG" in
      android|*providers.media*) continue ;;          # FUSE 本体/系统服务绝不碰
    esac
    PIDS=$(pgrep -f "^${PKG}(:|$)" 2>/dev/null) || continue
    for P in $PIDS; do fix_pid "$P"; done
  done
}

log "=== si_nsfix v0.5.0 start (nsenter=$NSENTER) ==="
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 20
( while true; do
    [ -d "$GUARD" ] || { log "module gone, watchdog exit"; exit 0; }
    [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 524288 ] && : > "$LOG"
    apply_zygote
    apply_running
    sleep 30
  done ) &
log "watchdog started"
